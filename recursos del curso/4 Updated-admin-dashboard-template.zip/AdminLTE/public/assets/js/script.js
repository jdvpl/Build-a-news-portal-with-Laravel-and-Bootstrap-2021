 $("#link-to-register").on("click",function(){
 	$("#login-close").trigger('click');
 });

  $("#link-to-login").on("click",function(){
 	$("#register-close").trigger('click');
 });